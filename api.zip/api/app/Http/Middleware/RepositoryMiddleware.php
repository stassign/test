<?php

namespace App\Http\Middleware;

use Closure;
use App\Repository;
use Illuminate\Http\Request;

class RepositoryMiddleware
{
    protected $validRepositories;

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $action = null)
    {
        $this->validRepositories = explode(';', env('REPO_VALID_LIST'));
        $repository_name = $request->input('repository')['name'];
        if (!in_array($repository_name, $this->validRepositories)) {
            return response('Repository not authorized.', 401);
        }

        return $next($request);
    }
}
