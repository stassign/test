<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Repository;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class HookController extends BaseController
{
    protected $path;

    /**
     * Create a new controller instance.
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    public function __construct(Request $request)
    {
        
    }
  public function getRecentPost() 
    {
       $results = Repository::orderBy('updated_at', 'DESC')->first();
      
       return response()->json(array('status'=>'success','results'=>json_decode($results->request_body)));
    }

    public function getPostBody($guid) 
    {
       $results = Repository::where('guid', $guid)->orderBy('updated_at', 'DESC')->first();
      
       return response()->json(array('status'=>'success','results'=>json_decode($results->request_body)));
    }
    /**
     * Pull Repository on push-hook.
     * 
     * @return void
     */

    public function onPush(Request $request) 
    {
        $header = $request->headers->all();
        if(!isset($header['x-github-delivery'])) {
            return response('unable to find guid', 404);
        } 
       
        $input = $request->all();
        $this->path = implode('/', [
            env('REPO_DIRECTORY'),
            $input['repository']['name']
        ]);
        Repository::create(array('guid' => $header['x-github-delivery'][0], 'request_body' => json_encode($input)));
        // $this->run([
        //     'git',
        //     '--git-dir=' . $this->path . '/.git',
        //     '--work-tree=' . $this->path,
        //     'pull',
        //     'origin',
        //     $input['repository']['default_branch']
        // ]);

        return response()->json(array('status'=>'success','results'=> array('msg' => 'Succesfully updated repository', 'guid' => $header['x-github-delivery'][0])));

    }
    
    /**
     * Run a process command
     * 
     * @var Array $command
     * @return Response
     */
    
    protected function run($command)
    {
        $process = new Process($command);
        
        try {
            $process->run();
            return response()->json(array('status'=>'success','results'=>'Succesfully updated repository'));
            return response('Succesfully updated repository.', 200);

        } catch(ProcessFailedException $exception) {
            return response($exception->getMessage(), 500);
        }
    }
}
